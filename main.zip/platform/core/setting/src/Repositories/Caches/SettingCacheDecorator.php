<?php

namespace Botble\Setting\Repositories\Caches;

use Botble\Setting\Repositories\Eloquent\SettingRepository;

/**
 * @deprecated
 */
class SettingCacheDecorator extends SettingRepository
{
}
