<div class="row">
    <div class="col-12 col-md-9 offset-md-3">
        {{ $slot }}
    </div>
</div>
