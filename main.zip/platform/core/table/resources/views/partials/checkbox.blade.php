<input
    class="form-check-input m-0 align-middle checkboxes"
    type="checkbox"
    name="id[]"
    value="{{ $id }}"
>
