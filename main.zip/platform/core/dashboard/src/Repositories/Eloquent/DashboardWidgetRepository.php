<?php

namespace Botble\Dashboard\Repositories\Eloquent;

use Botble\Dashboard\Repositories\Interfaces\DashboardWidgetInterface;
use Botble\Support\Repositories\Eloquent\RepositoriesAbstract;

class DashboardWidgetRepository extends RepositoriesAbstract implements DashboardWidgetInterface
{
}
